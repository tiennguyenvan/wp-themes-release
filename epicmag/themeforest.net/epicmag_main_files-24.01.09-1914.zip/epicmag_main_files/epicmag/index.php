<?php
// silent is golden