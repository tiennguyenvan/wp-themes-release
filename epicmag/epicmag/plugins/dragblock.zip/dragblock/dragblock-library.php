<?php
if (!defined('ABSPATH')) exit;
// Start the session
add_action('init', 'dragblock_block_start_session', 1);
function dragblock_block_start_session()
{
	if (!session_id()) {
		session_start();
	}
}

function dragblock_theme_json_merge($receiver, $provider)
{
	// var_dump($receiver);die();
	// a linear value, so we cannot make a recursion
	if (!is_array($receiver) || !is_array($provider)) {
		return $receiver;
	}

	foreach ($provider as $key => $value) {
		// not merge JS array
		if (is_array($value) && key($value) === 0) {
			continue;
		}
		// user did not define this property
		// simply set for them		
		if (!isset($receiver[$key])) {
			$receiver[$key] = $value;
			continue;
		}

		// user defined, we dive deeper to merge lower level properties
		$receiver[$key] = dragblock_theme_json_merge($receiver[$key], $value);
	}

	return $receiver;
}


/**
 * 
 */
function dragblock_url($path)
{
	return plugins_url($path, __FILE__);
}


/**
 * 
 */
function dragblock_get_image_srcsets($attachment_id)
{
	// this is a src
	// var_dump($attachment_id);
	if (!is_numeric($attachment_id)) {
		$attachment_id = attachment_url_to_postid($attachment_id);
		if (!$attachment_id) {
			return '';
		}
	}
	// var_dump('$attachment_id', $attachment_id);die();
	$attachment_id = (int) $attachment_id;

	$image_sizes = get_intermediate_image_sizes(); // Get all registered image sizes
	$image_srcset_values = array();

	foreach ($image_sizes as $image_size) {

		$image_src = wp_get_attachment_image_src($attachment_id, $image_size);

		if ($image_src) {
			$image_srcset_values[$image_src[1] . 'w'] = $image_src[0];
		}
	}

	$srcset = '';
	foreach ($image_srcset_values as $width => $url) {
		$srcset .= $url . ' ' . $width . ', ';
	}

	// Remove the trailing comma and space
	$srcset = rtrim($srcset, ', ');

	return $srcset;
}


function dragblock_is_reseved_terms($term)
{
	$reserved_terms = array(
		'action',
		'attachment',
		'attachment_id',
		'author',
		'author_name',
		'calendar',
		'cat',
		'category',
		'category__and',
		'category__in',
		'category__not_in',
		'category_name',
		'comments_per_page',
		'comments_popup',
		'custom',
		'customize_messenger_channel',
		'customized',
		'cpage',
		'day',
		'debug',
		'embed',
		'error',
		'exact',
		'feed',
		'fields',
		'hour',
		'link_category',
		'm',
		'minute',
		'monthnum',
		'more',
		'name',
		'nav_menu',
		'nonce',
		'nopaging',
		'offset',
		'order',
		'orderby',
		'p',
		'page',
		'page_id',
		'paged',
		'pagename',
		'pb',
		'perm',
		'post',
		'post__in',
		'post__not_in',
		'post_format',
		'post_mime_type',
		'post_status',
		'post_tag',
		'post_type',
		'posts',
		'posts_per_archive_page',
		'posts_per_page',
		'preview',
		'robots',
		's',
		'search',
		'second',
		'sentence',
		'showposts',
		'static',
		'status',
		'subpost',
		'subpost_id',
		'tag',
		'tag__and',
		'tag__in',
		'tag__not_in',
		'tag_id',
		'tag_slug__and',
		'tag_slug__in',
		'taxonomy',
		'tb',
		'term',
		'terms',
		'theme',
		'title',
		'type',
		'types',
		'w',
		'withcomments',
		'withoutcomments',
		'year',
		'about',
		'accordion',
		'admin-bar',
		'admin-bar',
		'admin-comments',
		'admin-gallery',
		'admin-menu',
		'admin-tags',
		'admin-widgets',
		'autosave',
		'backbone',
		'buttons',
		'clipboard',
		'code-editor',
		'code-editor',
		'colorpicker',
		'colors',
		'colors-fresh',
		'comment',
		'comment-reply',
		'common',
		'common',
		'cropper',
		'csslint',
		'custom-background',
		'custom-header',
		'custom-html-widgets',
		'customize-base',
		'customize-controls',
		'customize-controls',
		'customize-loader',
		'customize-models',
		'customize-nav-menus',
		'customize-nav-menus',
		'customize-preview',
		'customize-preview',
		'customize-preview-nav-menus',
		'customize-preview-widgets',
		'customize-selective-refresh',
		'customize-views',
		'customize-widgets',
		'customize-widgets',
		'dashboard',
		'dashboard',
		'dashicons',
		'deprecated-media',
		'edit',
		'editor',
		'editor-buttons',
		'editor-expand',
		'esprima',
		'farbtastic',
		'farbtastic',
		'forms',
		'handle',
		'heartbeat',
		'hoverIntent',
		'hoverintent-js',
		'htmlhint',
		'htmlhint-kses',
		'image-edit',
		'imagesloaded',
		'imgareaselect',
		'imgareaselect',
		'inline-edit-post',
		'inline-edit-tax',
		'install',
		'iris',
		'jcrop',
		'jcrop',
		'jquery',
		'jquery-color',
		'jquery-core',
		'jquery-effects-blind',
		'jquery-effects-bounce',
		'jquery-effects-clip',
		'jquery-effects-core',
		'jquery-effects-drop',
		'jquery-effects-explode',
		'jquery-effects-fade',
		'jquery-effects-fold',
		'jquery-effects-highlight',
		'jquery-effects-puff',
		'jquery-effects-pulsate',
		'jquery-effects-scale',
		'jquery-effects-shake',
		'jquery-effects-size',
		'jquery-effects-slide',
		'jquery-effects-transfer',
		'jquery-form',
		'jquery-hotkeys',
		'jquery-masonry',
		'jquery-migrate',
		'jquery-query',
		'jquery-serialize-object',
		'jquery-table-hotkeys',
		'jquery-touch-punch',
		'jquery-ui-accordion',
		'jquery-ui-autocomplete',
		'jquery-ui-button',
		'jquery-ui-core',
		'jquery-ui-datepicker',
		'jquery-ui-dialog',
		'jquery-ui-draggable',
		'jquery-ui-droppable',
		'jquery-ui-menu',
		'jquery-ui-mouse',
		'jquery-ui-position',
		'jquery-ui-progressbar',
		'jquery-ui-resizable',
		'jquery-ui-selectable',
		'jquery-ui-selectmenu',
		'jquery-ui-slider',
		'jquery-ui-sortable',
		'jquery-ui-spinner',
		'jquery-ui-tabs',
		'jquery-ui-tooltip',
		'jquery-ui-widget',
		'jshint',
		'json2',
		'jsonlint',
		'l10n',
		'language-chooser',
		'link',
		'list-revisions',
		'list-tables',
		'login',
		'masonry',
		'mce-view',
		'media',
		'media',
		'media-audio-widget',
		'media-audiovideo',
		'media-editor',
		'media-gallery',
		'media-gallery-widget',
		'media-grid',
		'media-image-widget',
		'media-models',
		'media-upload',
		'media-video-widget',
		'media-views',
		'media-views',
		'media-widgets',
		'mediaelement',
		'mediaelement',
		'mediaelement-core',
		'mediaelement-migrate',
		'mediaelement-vimeo',
		'moxiejs',
		'nav-menu',
		'nav-menus',
		'open-sans',
		'password-strength-meter',
		'plugin-install',
		'plupload',
		'plupload-handlers',
		'post',
		'postbox',
		'privacy-tools',
		'prototype',
		'quicktags',
		'revisions',
		'revisions',
		'sack',
		'schedule',
		'scriptaculous',
		'scriptaculous-builder',
		'scriptaculous-controls',
		'scriptaculous-dragdrop',
		'scriptaculous-effects',
		'scriptaculous-root',
		'scriptaculous-slider',
		'scriptaculous-sound',
		'set-post-thumbnail',
		'shortcode',
		'site-health',
		'site-health',
		'site-icon',
		'suggest',
		'svg-painter',
		'swfobject',
		'swfupload',
		'swfupload-all',
		'swfupload-handlers',
		'tags-box',
		'tags-suggest',
		'text-widgets',
		'theme',
		'themes',
		'thickbox',
		'thickbox',
		'underscore',
		'updates',
		'user-profile',
		'user-suggest',
		'utils',
		'widgets',
		'word-count',
		'wp-admin',
		'wp-ajax-response',
		'wp-api',
		'wp-api-request',
		'wp-auth-check',
		'wp-auth-check',
		'wp-backbone',
		'wp-block-library-theme',
		'wp-codemirror',
		'wp-codemirror',
		'wp-color-picker',
		'wp-color-picker',
		'wp-custom-header',
		'wp-edit-blocks',
		'wp-editor-font',
		'wp-embed',
		'wp-embed-template-ie',
		'wp-jquery-ui-dialog',
		'wp-lists',
		'wp-mediaelement',
		'wp-mediaelement',
		'wp-playlist',
		'wp-plupload',
		'wp-pointer',
		'wp-pointer',
		'wp-polyfill',
		'wp-sanitize',
		'wp-theme-plugin-editor',
		'wp-tinymce',
		'wp-tinymce',
		'wp-tinymce-lists',
		'wp-tinymce-root',
		'wp-util',
		'wpdialogs',
		'wplink',
		'xfn',
		'zxcvbn-async'
	);

	return in_array($term, $reserved_terms);
}
