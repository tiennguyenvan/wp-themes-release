
// set scroll classes to body tag
////////////////////////////////
let lastScrollTop = 0;
let lastScrollEvent = new Date().getTime();
//console.log('loaded')
window.addEventListener('scroll', () => {
    const currentScrollTop = window.scrollY || document.documentElement.scrollTop;
    // console.log("🚀 ~ currentScrollTop:", currentScrollTop)
    
    const currentScrollEvent = new Date().getTime();
    // console.log("🚀 ~ currentScrollEvent:", currentScrollEvent)

    if (currentScrollTop !== 0 && (Math.abs(currentScrollEvent - lastScrollEvent) < 100 || Math.abs(currentScrollTop - lastScrollTop) < 100)) {
        return;
    }
    lastScrollEvent = currentScrollEvent;
    
    if (currentScrollTop === 0) {
        // At the top of the page
        document.body.classList.remove('scroll-up', 'scroll-down', 'scroll');
        // console.log('Scroll zero');
    } else if (currentScrollTop > lastScrollTop) {
        // Scrolling down
        document.body.classList.remove('scroll-up');
        document.body.classList.add('scroll-down');        
        document.body.classList.add('scroll');
        // console.log('Scroll down');
    } else {
        // Scrolling up
        document.body.classList.remove('scroll-down');
        document.body.classList.add('scroll-up');        
        document.body.classList.add('scroll');
        // console.log('Scroll up');
    }

    lastScrollTop = currentScrollTop;
});
