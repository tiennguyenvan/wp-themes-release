<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
/ ************************************************************************************************
/ you are not allowed to modify this definition 
/ the whole system will collapse
/ !!! not longer than 20 chars
/ ************************************************************************************************
*/
define('DRAGBLOCK_FONT_LIB_SLUG', sanitize_key('dragblockFontLib')); // 16 chars

require_once DRAGBLOCK_PATH . 'admin/font-library/class-manage-fonts.php';
$manage_fonts_admin = new DragBlock_Manage_Fonts_Admin();

/**
 * Merging the fonts added by users
 */
add_filter('dragblock_default_theme_json', 'dragblock_default_theme_json_font_lib');
function dragblock_default_theme_json_font_lib($theme_json)
{
	/**
	 * Even when you don't define "theme" in the theme.json/settings/typography/fontFamilies
	 * The 
	 */
	if (!isset($theme_json['settings']['typography']['fontFamilies']['theme'])) {
		$theme_json['settings']['typography']['fontFamilies']['theme'] = array();
	}
	// save all existing font families defined by the theme author
	$existed_families = array();
	foreach ($theme_json['settings']['typography']['fontFamilies']['theme'] as $fontFamily) {
		if (empty($fontFamily['slug'])) {
			continue;
		}
		$existed_families[$fontFamily['slug']] = true;
	}

	// merge the existing font families with uploaded font families
	$uploaded_families = get_option(DRAGBLOCK_FONT_LIB_SLUG, array());

	foreach ($uploaded_families as $fontFamily) {
		if (empty($fontFamily['slug']) || empty($fontFamily['fontFace']) || !empty($existed_families[$fontFamily['slug']])) {
			continue;
		}
		$theme_json['settings']['typography']['fontFamilies']['theme'][] = ($fontFamily);
		$existed_families[$fontFamily['slug']] = true;
	}

	if (empty(DRAG_BLOCK_DEFAULT_THEME_JSON['settings']['typography']['fontFamilies'])) {
		return $theme_json;
	}

	// get default system fonts
	foreach (DRAG_BLOCK_DEFAULT_THEME_JSON['settings']['typography']['fontFamilies'] as $fontFamily) {
		if (empty($fontFamily['slug']) || !empty($existed_families[$fontFamily['slug']])) {
			continue;
		}
		$theme_json['settings']['typography']['fontFamilies']['theme'][] = ($fontFamily);
		$existed_families[$fontFamily['slug']] = true;
	}

	return $theme_json;
}


