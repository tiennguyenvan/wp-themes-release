<?php

/**
 * Plugin Name: DragBlock
 * Plugin URI: https://dragblock.com/
 * Requires at least: 5.9
 * Requires PHP: 7.0
 * Version: 0.0.3
 * Author: DragBlock.Com
 * Author URI: https://dragblock.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Description: Design stunning websites without any coding knowledge using DragBlock, the feature-rich Gutenberg plugin for lightning-fast site creation.
 * Text Domain: dragblock
 * Domain Path: /languages
 *
 * @package dragblock
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' )) {
	die;
}


define(
	'DRAGBLOCK_IS_LOCAL',
	!empty($_SERVER['OPENSSL_CONF']) && (strpos($_SERVER['OPENSSL_CONF'], 'C:/') === 0 ||
		strpos($_SERVER['OPENSSL_CONF'], 'D:/') === 0 ||
		strpos($_SERVER['OPENSSL_CONF'], 'E:/') === 0
	)
);
define('DRAGBLOCK_VERSION', DRAGBLOCK_IS_LOCAL ? time() : get_plugin_data(__FILE__)['Version']);
define('DRAGBLOCK_SITE_LOCALE', get_locale());
define('DRAGBLOCK_PATH', plugin_dir_path(__FILE__) );
// ------------------------------------------------------------------------------------------------
// this is for showing default css of this plugin so user could change by themeself
// however, we disabled it for now to simplify the working flow    
// ------------------------------------------------------------------------------------------------
define('DRAG_BLOCK_CUSTOM_DEFAULT_STYLE', false);


function dragblock_init_defines() {
	
    $upload_dir = wp_upload_dir();
    define('DRAGBLOCK_UPLOAD_DIR', $upload_dir['basedir'] . '/dragblock');
	define('DRAGBLOCK_UPLOAD_URL', $upload_dir['baseurl'] . '/dragblock');
    // Rest of your code
}
add_action('init', 'dragblock_init_defines', 1);


require_once 'dragblock-library.php';
require_once 'dragblock-enqueue.php';
require_once 'dragblock-admin.php';
require_once 'dragblock-register.php';
require_once 'dragblock-form.php';
require_once 'dragblock-fonts.php';
require_once 'dragblock-default-theme-json.php';
require_once 'dragblock-render.php';
require_once 'dragblock-shortcodes.php';
require_once 'dragblock-media.php';


function my_custom_mime_types( $mimes ) {
	// Add new mime types here
	$mimes['otf'] = 'application/octet-stream';
	$mimes['ttf'] = 'application/octet-stream';
	$mimes['woff'] = 'application/octet-stream';
	$mimes['woff2'] = 'application/octet-stream';

	return $mimes;
  }
  add_filter( 'upload_mimes', 'my_custom_mime_types' );
  