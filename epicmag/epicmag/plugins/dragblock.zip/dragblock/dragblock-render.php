<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Render Query / Functions
 * $dragBlockQueries:
 *  - A list of post/item ids queried from the database
 *  - You can access to each list via the $dragBlockCurListQueryId
 * $dragBlockCurListQueryId:
 *  - the id of the current active query
 *  - this is updated when a query is executed, along with $dragBlockQueries
 * $dragBlockCurListQueryIdItem:
 *  - the id of the current active item in the current active query
 *  - this is updated when a parse method is called
 */
global $dragBlockQueries;
global $dragBlockCurListQueryId;
global $dragBlockCurListQueryIdItem;
$dragBlockQueries = null;
$dragBlockCurListQueryId = null;
$dragBlockCurListQueryIdItem = null;

/**
 * Render_block_data will keep the oder of the block
 * Parent block will be rendered first, then their children will be rendered later
 * 
 * We did not do shortcode here because we could not access the content blocks with render_block_data
 * which is important for use to render shortcodes for the dragblock/text
 * 
 * However, since we moved the content of dragblock/text to attributes, we could really do shorcode here
 * And we really need to do shortcode here because if we escape the block attributes, all shortcodes attrs
 * will be added with &quot;, ex: [x y="1"] => [x y=&quot;1&quot;]
 */
add_filter('render_block_data', 'dragblock_render_block_data', 10, 2);
function dragblock_render_block_data($parsed_block, $source_block)
{

    // do the shortcode here so it will not render shortcodes with its own database queries
    // var_dump($parsed_block['blockName'], $parsed_block['attrs']);
    // process the blocks that have access to the database
    // if (empty($block['attrs']['dragBlockQueries'])) {
    //     return $parsed_block;
    // }
    // only process blocks from our plugins
    if (empty($parsed_block['attrs']['dragBlockClientId'])) {
        return $parsed_block;
    }

    // replace multilingual text contents
    $block_content = dragblock_render_parse_block_text($parsed_block);
    if ($block_content) {
        $parsed_block['attrs']['dragBlockParsedContent'] = $block_content;
    }

    // render attributes
    $block_attrs = dragblock_render_parse_block_attributes($parsed_block);
    if ($block_attrs) {
        $parsed_block['attrs']['dragBlockParsedAttrs'] = $block_attrs;
    }

    global $dragBlockQueries;
    global $dragBlockCurListQueryId;
    global $dragBlockCurListQueryIdItem;

    // add default query at the beginning
    // so any parse_post will have things to parse
    // even when there is not a get_post happend before.
    if (empty($dragBlockQueries)) {
        global $wp_query;
        $dragBlockCurListQueryId = 'default';
        $dragBlockCurListQueryIdItem = null;
        $dragBlockQueries[$dragBlockCurListQueryId] = array();
        if (property_exists($wp_query, 'posts') && is_array($wp_query->posts)) {
            foreach ($wp_query->posts as $post) {
                array_push($dragBlockQueries[$dragBlockCurListQueryId], $post->ID);
            }
        }
    }

    // process the custom queries
    if (!empty($parsed_block['attrs']['dragBlockQueries'])) {

        foreach ($parsed_block['attrs']['dragBlockQueries'] as $query) {
            if (!empty($query['disabled'])) {
                continue;
            }

            $slug = $query['slug'];
            $id = $query['id'];
            if (empty($query['params'])) {
                $query['params'] = array();
            }
            $params = $query['params'];

            // listing queries
            if (in_array($slug, array('WP_Query', 'WP_Query_Default'))) {

                $args = array(
                    'fields' => 'ids',
                );

                foreach ($query['params'] as $param) {
                    if (!empty($param['disabled']) || empty($param['value'])) {
                        continue;
                    }

                    // array attributes
                    $key = $param['slug'];
                    $val = $param['value'];

                    // special keys
                    if ($key === 'ignore_loaded_posts') {
                        if ($val) {
                            $args['post__not_in'] = array_merge(...array_values($dragBlockQueries));
                        }
                        continue;
                    }

                    // we can use shortcodes for the query parameters
                    if (strpos($val, '[dragblock.') !== false) {
                        $val = do_shortcode($val);
                    }

                    // this parameter require an array as its value
                    // following the requirements in WP_Query documentation
                    if (strpos($key, '__') !== false) {
                        $args[$key] = explode(',', $val);
                        continue;
                    }
                    $args[$key] = $val;
                }


                $dragBlockCurListQueryId = $id;

                if ($slug === 'WP_Query') {
                    $dragBlockQueries[$dragBlockCurListQueryId] = new WP_Query($args);
                    $dragBlockQueries[$dragBlockCurListQueryId] = $dragBlockQueries[$dragBlockCurListQueryId]->posts;

                    // always reset the query pointer when query a new query
                    $dragBlockCurListQueryIdItem = null;
                } else if ($slug === 'WP_Query_Default') {
                    // always reset the query pointer when query a new query
                    $dragBlockCurListQueryIdItem = null;
                    $dragBlockCurListQueryId = 'default';
                }
            }

            // other queries
            if ($slug === 'parse_item') {
                if (!empty($params['query_id'])) {
                    $dragBlockCurListQueryId = $params['query_id'];
                }
                if (!empty($params['item_index'])) {

                    $dragBlockCurListQueryIdItem = intval($params['item_index']);
                } else {
                    if ($dragBlockCurListQueryIdItem === null) {
                        $dragBlockCurListQueryIdItem = 0;
                    } else {
                        $dragBlockCurListQueryIdItem++;
                    }
                }
            }
        }
    }
    return $parsed_block;
}

/**
 * 
 */
function dragblock_render_parse_block_attributes($parsed_block)
{

    if (empty($parsed_block['attrs']['dragBlockAttrs'])) {
        return '';
    }

    $renderedAttrs = array();
    foreach ($parsed_block['attrs']['dragBlockAttrs'] as $attr) {
        // render enabled attr only
        if (
            !empty($attr['disabled']) ||
            !isset($attr['value']) ||
            empty($attr['slug'])
        ) {
            continue;
        }

        // !note: we don't call do shortcode here because
        // we need evidence for the pre-attribute processing

        // attributes that require for a specific language
        if (!empty($attr['locale'])) {
            // if matching locale, assign immediately
            if ($attr['locale'] === DRAGBLOCK_SITE_LOCALE) {
                $renderedAttrs[$attr['slug']] = $attr['value'];
            }
            // otherwise we assign the en_US as a fallback if did not assign before
            else if ($attr['locale'] === 'en_US' && empty($renderedAttrs[$attr['slug']])) {
                $renderedAttrs[$attr['slug']] = $attr['value'];
            }
            continue;
        }



        // preprocess some special attributes
        // for sizes attribute
        if ($attr['slug'] == 'sizes') {
            if (!empty($attr['devices']) && strlen($attr['devices']) < 3) {
                if ($attr['devices'] === 'd') $attr['value'] = '(min-width: 1025px) ' . $attr['value'];
                if ($attr['devices'] === 't') $attr['value'] = '(min-width: 768px) and (max-width: 1024px) ' . $attr['value'];
                if ($attr['devices'] === 'm') $attr['value'] = '(max-width: 767px) ' . $attr['value'];
                if ($attr['devices'] === 'dt' || $attr['devices'] === 'td') $attr['value'] =  '(min-width: 768px) ' . $attr['value'];
                if ($attr['devices'] === 'dm' || $attr['devices'] === 'md') $attr['value'] =  '(min-width: 1025px) ' . $attr['value'] . ', (max-width: 767px) ' . $attr['value'];
                if ($attr['devices'] === 'tm' || $attr['devices'] === 'mt') $attr['value'] =  '(max-width: 1024px) ' . $attr['value'];
            }
        }

        // save attributes
        if (empty($renderedAttrs[$attr['slug']])) {
            $renderedAttrs[$attr['slug']] = $attr['value'];
        } else {
            $renderedAttrs[$attr['slug']] .= ', ' . $attr['value'];
        }
    }

    // preprocessing missing attributes    
    if ($parsed_block['blockName'] === 'dragblock/image') {
        // load image asynchronously
        if (empty($renderedAttrs['loading'])) {
            $renderedAttrs['loading'] = 'lazy';
        }
        if (empty($renderedAttrs['decoding'])) {
            $renderedAttrs['decoding'] = 'async';
        }

        // optimize bandwidth using srcset
        if (!empty($renderedAttrs['src'])) {
            // src set for performance
            if (strpos($renderedAttrs['src'], '[dragblock.post.image.src') !== false) {
                // $start = strpos($renderedAttrs['src'], '[dragblock.post.image.src');
                // $end = strpos($renderedAttrs['src'], ']', $start);
                // if (empty($renderedAttrs['sizes']) && $end !== false) {
                //     $renderedAttrs['sizes'] = str_replace('[dragblock.post.image.src', '[dragblock.post.image.sizes', substr($renderedAttrs['src'], $start, $end - $start + 1));
                // }
                if (empty($renderedAttrs['alt'])) {
                    $renderedAttrs['alt'] = '[dragblock.post.title]';
                }
                if (empty($renderedAttrs['srcset'])) {
                    $renderedAttrs['srcset'] = '[dragblock.post.image.srcset]';
                }
            }
            else {
                $srcsets = dragblock_get_image_srcsets($renderedAttrs['src']);
                
                if ($srcsets) {
                    $renderedAttrs['srcset'] = $srcsets;
                }
            }
        }
    }

    // inserting the attributes
    // do_shortcode before esc_attr to avoid escaping "" characters of shortcodes attributes
    // ex: [dragblock.post.image.url size="medium"] will be 
    // [dragblock.post.image.url size=&quot;medium&quot;] if escaped
    $attrString = '';

    if (!empty($renderedAttrs['name']) && dragblock_is_reseved_terms($renderedAttrs['name'])) {
        $renderedAttrs['name'] .=  '__dragblock_wp_reseved_terms';
    }

    foreach ($renderedAttrs as $slug => $value) {        
        $attrString .= (sanitize_key($slug) . '="' . esc_attr(do_shortcode($value)) . '"');
    }

    return $attrString;
}

/**
 * replace multilingual text contents    
 */
function dragblock_render_parse_block_text($parsed_block)
{
    // this is don't have multilingual text content
    if (empty($parsed_block['attrs']['dragBlockText'])) {
        return '';
    }

    $block_content = '';

    $textEnUS = '';
    // search for the right text
    foreach ($parsed_block['attrs']['dragBlockText'] as $text) {
        // we may need to add device here later
        if (
            empty($text['slug']) ||
            !isset($text['value']) ||
            $text['value'] === '' ||
            !empty($text['disabled'])
        ) {
            continue;
        }

        // we want to find the text for our current locale only
        if ($text['slug'] === DRAGBLOCK_SITE_LOCALE) {
            $block_content = $text['value'];
            break;
        }

        // we collect English text for a fallback
        if ($text['slug'] === 'en_US') {
            $textEnUS = $text['value'];
            continue;
        }
    }

    // if there is no content for the locale, return the english one
    if ($block_content === '' && $textEnUS !== '') {
        $block_content = $textEnUS;
    }

    

    // otherwise, return what we collected
    return do_shortcode($block_content);
}


/**
 * Render_block_data will revert the block order
 * Parent block will be rendered after their children
 * Here is where we actually render the attributes and content
 * by inserting them into their place
 */
add_filter('render_block', 'dragblock_render_block', 10, 2);
function dragblock_render_block($block_content, $parsed_block)
{
    // only process blocks from our plugins
    if (empty($parsed_block['attrs']['dragBlockClientId'])) {
        return $block_content;
    }

    $block_content = dragblock_render_insert_content($block_content, $parsed_block);
    $block_content = dragblock_render_insert_attributes($block_content, $parsed_block);
    $block_content = dragblock_render_insert_uid($block_content, $parsed_block);

    // render extra content of form
    $block_content = dragblock_render_form($block_content, $parsed_block);

    return $block_content;
}

/**
 * Insert attributes into block's attribute tag
 */
function dragblock_render_insert_attributes($block_content, $parsed_block)
{
    if (empty($parsed_block['attrs']['dragBlockParsedAttrs'])) {
        return $block_content;
    }
    $postStartStart = strpos($block_content, '<');
    if ($postStartStart === false) return $block_content;

    $posStartSpace = strpos($block_content, ' ', $postStartStart);
    $posStartClose = strpos($block_content, '>', $postStartStart);
    $posStart = $posStartSpace;

    if ($posStart === false) {
        $posStart = $posStartClose;
    } else if ($posStartClose !== false && $posStartClose < $posStart) {
        $posStart = $posStartClose;
    }

    if ($posStart === false) {
        return $block_content;
    }

    $block_content =
        substr($block_content, 0, $posStart) . ' ' .
        $parsed_block['attrs']['dragBlockParsedAttrs'] .
        substr($block_content, $posStart);

    return $block_content;
}

/**
 * insert content between block's opening and ending tags
 */
function dragblock_render_insert_content($block_content, $parsed_block)
{
    if (empty($parsed_block['attrs']['dragBlockParsedContent'])) {
        return $block_content;
    }
    $posClose = strrpos($block_content, '</');
    
    // there is no anchor to insert before
    if ($posClose === false) {
        return $block_content;
    }

    $block_content =
        substr($block_content, 0, $posClose) .
        $parsed_block['attrs']['dragBlockParsedContent'] .
        substr($block_content, $posClose);
    // var_dump($block_content, $parsed_block['attrs']['dragBlockParsedContent']);
    return $block_content;
}

/**
 * insert uid class name to class attribute of block tag
 */
function dragblock_render_insert_uid($block_content, $parsed_block)
{
    // this is from the enqueue process
    global $dragblock_uids;

    $uidAccessKey = $parsed_block['blockName'] . $parsed_block['attrs']['dragBlockClientId'];
    if (!isset($dragblock_uids[$uidAccessKey])) {
        return $block_content;
    }

    $classKey = 'class="';
    $postStartClass = strpos($block_content, $classKey);
    $postStartClose = strpos($block_content, '>');

    if ($postStartClass === false || $postStartClass >= $postStartClose) {
        return $block_content;
    }

    // replace long selectors with short uids
    $block_content =
        substr($block_content, 0, $postStartClass + strlen($classKey)) .
        ($dragblock_uids[$uidAccessKey]) . ' '
        . substr($block_content, $postStartClass + strlen($classKey));

    return $block_content;
}
