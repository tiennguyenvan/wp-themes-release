1. Access Settings / Sneeit Demo to access option page
2. Select Categories and number of posts for each that you want to create
3. Define menu structure with the following json format
	{
		'title of menu' : {
			'icon' : 'fa-home',
			'url' : '#',
			'mega' : true,
			'target' : '_blank'
			'sub' : {
				list of menu item object like the parent structure
			}
		}
	}
		