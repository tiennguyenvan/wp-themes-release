const gulp = require('gulp');
const phpMinify = require('gulp-php-minify');

function minifyPHP() {
  return gulp
    .src('src/**/*.php') // Adjust the source path as per your project's structure
    .pipe(phpMinify({ binary: 'php' })) // Specify the path to the PHP binary if it's not in the system's PATH
    .pipe(gulp.dest('build')); // Adjust the destination path as per your project's structure
}

exports.minifyPHP = minifyPHP;
