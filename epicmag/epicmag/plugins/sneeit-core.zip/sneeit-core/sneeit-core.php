<?php
/*
Plugin Name: Sneeit Core
Plugin URI:  https://sneeit.com
Description: This plugin will help theme developers import demos, and authenticating and updating their themes
Version:     1.0
Author:      Tien Nguyen
Author URI:  https://sneeit.com
Requires PHP: 7.0
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: sneeit-core
@package sneeit-core
*/

define('SNEEIT_CORE_PLUGIN_VERSION', time());
/******************************************/

/*DEFINES*/

/*common*/
define('SNEEIT_CORE_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SNEEIT_CORE_PLUGIN_PATH', plugin_dir_path(__FILE__));

/*URL parts*/
define('SNEEIT_CORE_BUILD_URL', SNEEIT_CORE_PLUGIN_URL . 'build/');
define('SNEEIT_CORE_BUILD_PATH', SNEEIT_CORE_PLUGIN_PATH . 'build/');
define('SNEEIT_CORE_IMAGE_PATH', SNEEIT_CORE_PLUGIN_PATH . 'images/');
define('SNEEIT_CORE_IMAGE_URL', SNEEIT_CORE_PLUGIN_URL . 'images/');
define('SNEEIT_CORE_BLANK_IMAGE_PATH', SNEEIT_CORE_IMAGE_PATH . 'blank.png');
define('SNEEIT_CORE_BLANK_IMAGE_URL', SNEEIT_CORE_IMAGE_URL . 'blank.png');


function sneeit_core_include_files_recursive($folder_path)
{
    $file_paths = glob($folder_path . '/*.php');

    foreach ($file_paths as $file_path) {
        if (basename($file_path) === 'index.asset.php') {
            continue;
        }
        require_once $file_path;
    }

    $sub_folders = glob($folder_path . '/*', GLOB_ONLYDIR);

    foreach ($sub_folders as $sub_folder) {
        sneeit_core_include_files_recursive($sub_folder);
    }
}

$folder_path = SNEEIT_CORE_PLUGIN_PATH . 'build/';
sneeit_core_include_files_recursive($folder_path);


////////////////////////////////