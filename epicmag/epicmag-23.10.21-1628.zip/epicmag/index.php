<?php
// silent is golden